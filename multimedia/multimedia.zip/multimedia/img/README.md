# DIW - IMG - Retoque de imagen

/*------efecto 1 ---------*/

fondo -> mezclador de canales
"R" : "-200%"
"G" : "-118%"
"B" : "+176%"

/*------efecto 2 ---------*/

piel -> Mascara de capa
se ha creado una capa nueva por encima con un color 
y mascara de capa para que solo afectara a la piel
"modo" : "multiplicar"

/*------efecto 3 ---------*/

gorra -> perspectiva
"horizontal" : "-100%"
"vertical" : "-20%"

/*------efecto 4 ---------*/

nube -> filtro ps
"bosquejar" : "Modelo de semitono"
"color 1" : "blanco"
"color 2" : "cyan"
"opciones de fusion" : "sombra interior"
"distancia" : "12px"
"retraer" : "5%"
"tamaño" : "10px"



#exports jpg, png y gif