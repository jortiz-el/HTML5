# DIW - Adobe Premiere - Retoque de Video

/*------efecto  ---------*/

seg -> 1 efecto molinete
"angulo" : "4x0,0º" => "0,0º"
"radio del molinete" : "50" => "75"


/*------efecto 2 ---------*/

seg -> 3 efecto velocidad
"invertir velocidad" : "100%"

/*------efecto 3 ---------*/

seg -> 5 efecto correccion de gamma
"gama" : "10" => "1"

/*------efecto 4 ---------*/

seg -> 6 efecto de luz
"centro" : "495,460"
"radio mayor" : "26"
"intensidad luz ambiental" :"72" => "-26"



#exports mpg, ogg, webm