#DIW - archivo animation.html - CSS3

/*------animacion ---------*/

animacion usando la tecnica de sprite 
"archivo" : "logo2.png"

animacion en CSS creando un loop infinito 
"propiedad" : "animation"
"propiedad" : "transform: translate()"

prefix para navegadores
 "-webkit-"


#HTML5, CSS3