#DIW - Extras - Animacion y Video

/*------animacion ---------*/

animacion del menu de navegacion
"flecha" : "transform: rotate(90deg)"
"submenu" : "overflow: visible"
"transition" : "all .6s"

creacion nuevos elementos en video controler
"mute" : "boton doble posicion"
"range" : "control de rango del tiempo + tiempo real y total"
"efecto click" : "transform: scale"

