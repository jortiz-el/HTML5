# DIW - Audio Audacity - Pachelbel's_Canon

/*------efecto 1 ---------*/

seg-> 0 al seg-> 5 
"efecto" : "eco"
"tiempo retraso" : 1 (segundos)
"factor de decaimiento" : 0.8

/*------efecto 2 ---------*/

seg->4 al seg->8
"efecto" : "revertir"
"fundido" : "fundido clips y suavisado final"


#exports MP3, ogg y FLAC



